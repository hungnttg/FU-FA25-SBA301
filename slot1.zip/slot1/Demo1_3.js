//an hien noi dung khi click button
import { useState } from "react";
function D1_3(){
    const [visible,setVisible]=useState(true);
    //code
    //layout
    return(
        <div>
            {/* button */}
            <button onClick={()=>setVisible(!visible)}>
                {visible ? "An" : "Hien"} noi dung
            </button>
            {/* text */}
            {visible && <p>Day la noi dung co the an/hien</p>}
        </div>
    );
}
export default D1_3;
//yeu cau bai tap:
//Xay dung ung dung quan ly cong viec
//cho phep: nhâp vào 1 đầu việc -> cick Add thì công việc đó
//hiển thị lên danh sách