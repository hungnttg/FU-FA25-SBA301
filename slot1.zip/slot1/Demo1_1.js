//vi du 1: hien thi 1 danh sach
function D1_1(){
    //code
    //du lieu can hien thi
    const students=["An","Binh","Chung","Dung"];
    //layout
    return(
        <div>
            <h2>Danh sach sinh vien</h2>
            <ul>
                {/* vong lap */}
                {
                    students.map((s,index)=>(
                        <li key={index}>{s}</li>
                    ))
                }
            </ul>
        </div>
    );
}
export default D1_1;//export de su dung o cho khac