// tao form nhap lieu; moi lan nhap lieu thi can lay ket qua ra man hinh
import { useState } from "react";
function D1_2(){
    //code
    const [name, setName]=useState(""); //khai bao trang thai
    //layout
    return(
        <div>
            <h2>Nhap ten cua ban</h2>
            <input type="text" placeholder="Nhap ten..."
            value={name}
            onChange={(e)=> setName(e.target.value)}
            />
            {/* goi gu lieu cua trang thai */}
            <p>Xin chao , {name}</p>
        </div>
    );
}
export default D1_2;