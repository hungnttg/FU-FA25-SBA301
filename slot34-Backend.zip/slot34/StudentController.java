package com.example.t1.slot34;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {
    private final StudentRepository repo;
    public StudentController(StudentRepository repo) {
        this.repo = repo;
    }
    @GetMapping
    public List<Student> getAll() {
        return repo.findAll();
    }
    @PostMapping
    public Student add(@RequestBody Student s) {
        return repo.save(s);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        repo.deleteById(id);
    }
}

