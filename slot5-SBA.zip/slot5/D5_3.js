//Modal (Hien thi chi tiet san pham)
import { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import 'bootstrap/dist/css/bootstrap.min.css';
function D5_3(){
    //code
    const [show,setShow]=useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    //layout
    return(
        <div style={{padding:"20px"}}>
            <Button variant="info" onClick={handleShow}>Xem chi tiet SP</Button>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Thong tin san pham</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Day la mo ta cho tiet cua san pham
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>Dong</Button>
                    <Button variant="primary" onClick={handleClose}>Mua ngay</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}
export default D5_3;