//Tao 1 trang web bán hàng nhỏ
//Navbar (Trang chủ, Sản phẩm, Giỏ hàng)
//Danh sách sản phẩm (Card + Button + "Xem chi tiết")
//Khi nhấn "Xem chi tiết" => hiển thị Model với thông tin sản phẩm
//Thêm form đăng
// slot5/D5_4.js
import React, { useState, useEffect } from "react";
import {
  Navbar,
  Nav,
  Container,
  Card,
  Button,
  Row,
  Col,
  Modal,
  Form,
  Spinner,
} from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
function D5_4() {
  const [products, setProducts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:8083/PE2025/api/sanpham/get")
      .then((res) => res.json())
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Lỗi khi tải dữ liệu:", err);
        setLoading(false);
      });
  }, []);

  const handleShowDetail = (product) => {
    setSelectedProduct(product);
    setShowModal(true);
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    alert("Đăng nhập thành công!");
    setShowLogin(false);
  };

  return (
    <>
      {/* Navbar */}
      <Navbar bg="light" expand="lg" fixed="top" className="shadow-sm">
        <Container>
          <Navbar.Brand href="#">MiniShop</Navbar.Brand>
          <Navbar.Toggle />
          <Navbar.Collapse>
            <Nav className="me-auto">
              <Nav.Link href="#">Trang chủ</Nav.Link>
              <Nav.Link href="#">Sản phẩm</Nav.Link>
              <Nav.Link href="#">Giỏ hàng</Nav.Link>
            </Nav>
            <Button variant="outline-primary" onClick={() => setShowLogin(true)}>
              Đăng nhập
            </Button>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Nội dung */}
      <div style={{ marginTop: "90px" }}>
        <Container>
          {loading ? (
            <div className="text-center my-5">
              <Spinner animation="border" />
              <p>Đang tải sản phẩm...</p>
            </div>
          ) : (
            <Row>
              {products.map((product) => (
                <Col key={product.id} md={3} className="mb-4">
                  <Card className="h-100 shadow-sm">
                    <Card.Img
                      variant="top"
                      src={product.hinhanhsanpham}
                      style={{ height: "200px", objectFit: "contain" }}
                    />
                    <Card.Body>
                      <Card.Title
                        className="text-truncate"
                        title={product.tensanpham}
                      >
                        {product.tensanpham}
                      </Card.Title>
                      <Card.Text className="text-danger fw-bold">
                        {product.giasanpham.toLocaleString()}₫
                      </Card.Text>
                      <Button
                        variant="primary"
                        onClick={() => handleShowDetail(product)}
                      >
                        Xem chi tiết
                      </Button>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          )}
        </Container>
      </div>

      {/* Modal chi tiết sản phẩm */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>{selectedProduct?.tensanpham}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <img
            src={selectedProduct?.hinhanhsanpham}
            alt={selectedProduct?.tensanpham}
            className="img-fluid mb-3"
          />
          <p className="text-danger fw-bold">
            Giá: {selectedProduct?.giasanpham.toLocaleString()}₫
          </p>
          <p>{selectedProduct?.motasanpham}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Đóng
          </Button>
          <Button variant="success">Thêm vào giỏ</Button>
        </Modal.Footer>
      </Modal>

      {/* Modal đăng nhập */}
      <Modal show={showLogin} onHide={() => setShowLogin(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Đăng nhập</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleLoginSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" placeholder="Nhập email" required />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Mật khẩu</Form.Label>
              <Form.Control type="password" placeholder="Nhập mật khẩu" required />
            </Form.Group>
            <Button type="submit" className="w-100">
              Đăng nhập
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default D5_4;
