//Login Form
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
function D5_2(){
    return(
        <div style={{width:"380px",margin: "50px auto"}}>
            <h2>Dang nhap</h2>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Email</Form.Label>
                    <Form.Control type="email" placeholder="nhap email" />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>Mat khau</Form.Label>
                    <Form.Control type="password" placeholder="Nhap mat khau" />
                </Form.Group>
                <Button variant="primary" type="submit">Dang nhap</Button>
            </Form>
        </div>
    );
}
export default D5_2;