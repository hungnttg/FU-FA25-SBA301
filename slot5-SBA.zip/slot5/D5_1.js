//navvar
import  Container from "react-bootstrap/Container";
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
function D5_1(){
    return(
        <Navbar bg="dark" variant="dark" expand="lg">
            <Container>
                <Navbar.Brand href="#home">MyShop</Navbar.Brand>
                <Nav className="me-auto">
                    <Nav.Link href="#home">Trang chu</Nav.Link>
                    <Nav.Link href="#products">San pham</Nav.Link>
                    <Nav.Link href="#about">Gioi thieu</Nav.Link>
                </Nav>
            </Container>
        </Navbar>
    ); 
}
export default D5_1;
