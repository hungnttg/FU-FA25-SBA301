module.exports = {
    images: {
        domains: ['images.unsplash.com'],
        formats: ['image/avif','image/webp'],
    },
}