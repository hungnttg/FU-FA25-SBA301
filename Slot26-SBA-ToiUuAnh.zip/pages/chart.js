//pages/chart.js
//dynamic import (lazy loading component nang)=>chi load component nang khi can thiet
import dynamic from "next/dynamic";
import { useState } from "react";
//import Chart khi nguoi dung click button = Lazy load
const Chart = dynamic(()=>import('../components/Chart'),{ssr:false});
export default function ChartPage(){
    const [showChart,setShowChart]=useState(false);
    return(
        <main style={{padding:20}}>
            <h1>Dynamic import</h1>
            <button onClick={()=>setShowChart(true)}>Hien bieu do</button>
            {showChart && <Chart/>}
        </main>
    );
}