//page/prefetch-demo.js
//dieu khien thu cong viecj chuyen trang de tang hieu suat
import Link from "next/link";
export default function PrefetchDemo(){
    return(
        <main style={{padding:20}}>
            <h1>Prefetch demo</h1>
            <p>Nhan vao cac link duoi day de xem toc do chuyen trang</p>
            {/* tu dong prefetch khi xuat hien trong viewport */}
            <Link href="/posts" prefetch={true}>
                <button style={{marginLeft:10}}>Den trang bai viet (Prefetch On)</button>
            </Link>
            {/* tat prefetch de so sang */}
            <Link href="/chart" prefetch={false}>
                <button>Den trang bieu do (Prefetch Off)</button>
            </Link>
        </main>
    );
}