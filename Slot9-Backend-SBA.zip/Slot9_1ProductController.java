package com.example.t1.slot9;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/products91")
@CrossOrigin(origins = "http://localhost:3000") // cho phép React
public class Slot9_1ProductController {

    private List<String> products = new ArrayList<>(List.of("iPhone 14", "Samsung S23", "Xiaomi 13"));

    @GetMapping
    public List<String> getProducts() {
        return products;
    }

    @DeleteMapping("/{name}")
    public String deleteProduct(@RequestHeader("Authorization") String auth, @PathVariable String name) {
        if(auth == null || !auth.contains("ADMIN")) return "Forbidden";
        products.removeIf(p -> p.equals(name));
        return "Deleted " + name;
    }
}
