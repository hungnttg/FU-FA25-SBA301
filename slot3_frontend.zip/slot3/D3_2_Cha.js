import Con_D3_2_Card from "./D3_2_Con";
function D3_2_Cha(){
    return(
        <div>
            <h1>Demo Children Props</h1>
            {/* truyen du lieu cho thanh phan con */}
            <Con_D3_2_Card>
                <p>No dung trong the Card</p>
            </Con_D3_2_Card>
            <Con_D3_2_Card>
                <button>Bam vao day</button>
            </Con_D3_2_Card>
        </div>
    );
}
export default D3_2_Cha;