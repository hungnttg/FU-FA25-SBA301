import { useState,useEffect } from "react";
export default function D3_3(){
    //code
    const [sp,setSp]=useState([]);//quan ly trang thai
    //ham load du lieu moi khi co su thay doi
    useEffect(()=>{
        //doc link API
        fetch("http://localhost:8083/PE2025/api/sanpham/get")
        .then(r => r.json()) //chuyen sang json
        .then(setSp) //chuyen sang mang
        .catch(e=>console.error("API loi: ",e));
    },[]);
    //layout
    return(
        <div style={{padding:20}}>
            <h1>Danh sach san pham</h1>
            {!sp.length ? "Dang tai..." : (
                <div style={{display:"grid", gridTemplateColumns: "repeat(3,1fr)", gap:20}}>
                    {sp.map(s => (
                        <div key={s.id} style={{border: "1px solid #ccc", padding:10}}>
                            <img src={s.hinhanhsanpham} alt={s.tensanpham}
                            style={{width:"100%",height:200}} />
                            <h3>{s.tensanpham}</h3>
                        </div>
                    ))}
                </div>    
            )}
        </div>
    );
}