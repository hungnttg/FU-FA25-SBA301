//su dung props.children de boc noi dung
function Con_D3_2_Card({children}){
    return(
        <div style={{border: "1px solid grey",padding:"10px",}}>
            {children}
        </div>
    );
}
export default Con_D3_2_Card;