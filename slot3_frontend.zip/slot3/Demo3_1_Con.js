function Demo3_1_Con_Student({name,age}){
    return(
        <div>
            <p>Ho ten: {name}</p>
            <p>Tuoi: {age}</p>
        </div>
    );
}
export default Demo3_1_Con_Student;