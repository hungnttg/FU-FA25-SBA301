// truyen ten sinh vien qua props
import Demo3_1_Con_Student from './Demo3_1_Con';
function Demo3_1(){
    return(
        <div>
            <h1>Demo props</h1>
            {/* truyen du lieu tu cha sang con */}
            <Demo3_1_Con_Student name="Lan" age={21}/>
            <Demo3_1_Con_Student name="Hai" age={20} />
        </div>
    );
}
export default Demo3_1;