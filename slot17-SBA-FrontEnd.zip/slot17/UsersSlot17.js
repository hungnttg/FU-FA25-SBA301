import React,{useEffect,useState} from "react";
export default function UsersSlot17(){
    //code 
    const [users,setUsers]=useState([]);
    const [selectedUser,setSelectedUser]=useState(null);
    //--load danh sach user
    useEffect(()=>{
        const fetchUsers = async () =>{
            try {
                const res = await fetch("http://localhost:8083/slot17/users");
                const data=await res.json();//chuyen sang json
            setUsers(data);//cap nhat vao bien data
            } catch (error) {
                console.error("Loi: ",error);
            }
        };
        fetchUsers();
    },[]);
    //xem chi tiet user
    const viewDetail = async (user) =>{
        const href = user?._links?.self;
        if(!href){
            console.error("no seft link for user: ",user);
            return;
        }
        try {
            const res = await fetch(href);//dung url day du tu _links.self
            if(!res.ok) throw new Error("loi http: "+res.status);
            const data = await res.json();
            setSelectedUser(data);
        } catch (error) {
            console.error("Fetch user detail error: ",error);
        }
    };

    //layout
    return(
        <div>
            <h2>HATEOAS</h2>
            <button onClick={()=>setSelectedUser(null)}>Load users</button>
            <ul>
                {users.map((u)=>(
                    <li key={u.id}>
                        {u.name} ({u.email}){" "}
                        <button onClick={()=>viewDetail(u)}>View detail</button>
                    </li>
                ))}
            </ul>
            {/* hien thi */}
            {selectedUser && (
                <div>
                    <h3>User detail</h3>
                    <p>ID: {selectedUser.id}</p>
                    <p>Name: {selectedUser.name}</p>
                    <p>Email: {selectedUser.email}</p>
                </div>
            )}
        </div>
    );
}