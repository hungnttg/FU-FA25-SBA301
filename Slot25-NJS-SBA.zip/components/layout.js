import Link from "next/link";
import React from "react";
export default function Layout({children}){
    return(
        <div style={{fontFamily:"Arial, sans-serif"}}>
            <header style={{padding:"10px",backgroundColor:"#AA11"}}>
                <nav style={{display:"flex", gap:"20px"}}>
                    <Link href="/">Home</Link>
                    <Link href="/about">About</Link>
                    <Link href="/blog">Blog</Link>
                    <Link href="/comments">Comment</Link>
                </nav>
            </header>
            <main style={{padding:"20px"}}>{children}</main>
            <footer style={{padding:"10px", backgroundColor:"#ff11",marginTop:"20px"}}>
                &copy; 2025 my website
            </footer>
        </div>
    );
}