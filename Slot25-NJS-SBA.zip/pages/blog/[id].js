import { useRouter } from "next/router";
import { useEffect,useState } from "react";
export default function BlogDetail(){
    const router = useRouter();
    const {id} =router.query;
    const [post,setPost]=useState(null);
    useEffect(()=>{
        if(!id) return;
        fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
        .then((res)=>res.json())
        .then((data)=>setPost(data));
    },[id]);
    if(!post) return <p>Loading...</p>;
    return(
        <div>
            <h2>{post.title}</h2>
            <p>{post.body}</p>
        </div>
    );
}