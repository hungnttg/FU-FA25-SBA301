package com.example.t1.slot29;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot29/shops")
@CrossOrigin(origins = "http://localhost:5173")
public class ShopController {
    @Autowired
    private ShopRepository repo;
    @GetMapping
    public List<Shop> getAll() {
        return repo.findAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Shop> getById(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Shop create(@RequestBody Shop shop) {
        return repo.save(shop);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Shop> update(@PathVariable Long id, @RequestBody Shop s) {
        return repo.findById(id).map(shop ->{
            shop.setShopName(s.getShopName());
            shop.setOwner(s.getOwner());
            shop.setType(s.getType());
            shop.setOpenTime(s.getOpenTime());
            return ResponseEntity.ok(repo.save(shop));
        }).orElse(ResponseEntity.notFound().build());
    }
    @GetMapping("/types")
    public List<String> getTypes() {
        return List.of("Science", "Math", "Computer Science");
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        repo.deleteById(id);
        return ResponseEntity.ok().build();
    }
}
