import React from "react";
import Student from "./Slot20_Con";
export default function VD20_1_Cha(){
    //code
    //---du lieu truyen cho Con
    const students = [
        {id:1,name:"Nguyen Van A", age:22, marjor:"CNTT"},
        {id:2,name:"TRan Van B",age:20,marjor: "QTKD"},
        {id:3,name:"Nguyen Thi D",age:21,marjor:"Ketoan"}
    ];
    //layout
    return(
        <div>
            <h1>Danh acsh sinh vien</h1>
            {students.map(s=>(
                <Student
                    key={s.id}
                    name={s.name}
                    age={s.age}
                    marjor={s.marjor}
                />
            ))}
        </div>
    );
}