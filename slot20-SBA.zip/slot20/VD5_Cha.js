import React,{useState} from "react";
import VD5_Cart from "./VD5_Cart";
import VD5_ProductList from "./VD5_ProductList";
export default function VD5_Cha(){
    const [cart,setCart]=useState([]);
    const products = [
        {id:1,name:"IP17",price: 50000000},
        {id:2,name:"IP17 pro",price: 55000000},
        {id:3,name:"IP17 promax",price: 60000000},
    ];
    const addToCart = (product) =>{
        setCart([...cart,product]);
    }
    return(
        <div>
            <h1>Cua hangh dien thoaiu</h1>
            <VD5_ProductList products={products} addToCart={addToCart}/>
            <VD5_Cart items={cart}/>
        </div>
    );
}