import React from "react";
export default function VD5_ProductList({products,addToCart}){
    return(
        <div>
            <h2>Danh sach san pham</h2>
            {products.map((p)=>(
                <div key={p.id} style={{marginBottom:"10px"}}>
                    <span>{p.name} - {p.price.toLocaleString()} VND</span>
                    <button onClick={()=>addToCart(p)} style={{marginLeft:"10px"}}>
                        Them vao gio hang
                    </button>
                </div>
            ))}
        </div>
    );
}