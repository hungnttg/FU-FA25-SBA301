import React from "react";
export default function VD5_Cart({items}){
    return(
        <div style={{marginTop:"20px"}}>
            <h2>Gio hang co {items.length} san pham</h2>
            <ul>
                {items.map((item,index)=>(
                    <li key={index}>{item.name} - {item.price} VND</li>
                ))}
            </ul>
        </div>
    );
}