//hien thi thong tin sinh vien, diem, tinh toan voi JSX
function D2_1(){
//code
const student={name: "An",age: 21};
const score = 8.5;
//layout
return(
    <div>
        <h1>Thong tin sinh vien</h1>
        <p>Ten: {student.name}</p>
        <p>Tuoi: {student.age}</p>
        <p>Diem so: {score}</p>
        <p>Ket qya: {score >= 5 ? "Pass" : "Faile"}</p>
        <p>Tinh toan: {2*4-1}</p>
    </div>
);
}
export default D2_1;