//nhan phim bam => hien thi alert voi ten sinh vien cu the
function D2_2(){
//code
    //dinh nghia ham
    const sayHello=(name)=>{
        alert(`Xin chao ${name}`); //truyen tham so vao trong chuooi
    };
    //layout
    return(
        <div>
            <h1>Xu ly su kien</h1>
            <button onClick={()=>sayHello("Binh")}>Chao Binh</button>
            <button onClick={()=>sayHello("Chung")}>Chao Chung</button>
        </div>
    );
}
export default D2_2;