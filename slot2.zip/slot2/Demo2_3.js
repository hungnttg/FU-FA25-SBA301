//binding 2 chieu: nhap lieu den dau thi hien thi text den do
import { useState } from "react";
function D2_3(){
//code
    const [email,setEmail]=useState("");//khai bao trang thai va cach thay doi trang thai
//layout
    return(
        <div>
            <h1>Data Binding</h1>
            <input
                type="email"
                placeholder="Nhap email..."
                value={email}
                onChange={(e)=>setEmail(e.target.value)}
            />
            <p>Email cua ban: {email}</p>
        </div>
    );
            
}
export default D2_3;