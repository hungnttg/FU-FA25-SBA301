//Bai tap: tao 2 button tang giam so; moi khi nguoi dung click vao dau + thi ket qua tang
//moi khi nguoi dung cick vao button - thi ket qua giam
//cho phep thay doi buoc nhay (buoc nhay mac dinh la 1)