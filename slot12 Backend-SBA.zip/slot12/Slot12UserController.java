package com.example.t1.slot12;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot12user")
@CrossOrigin(origins = "http://localhost:3000")
public class Slot12UserController {
    @Autowired
    private Slot12UserService service;
    @GetMapping
    public List<Slot12User> getAll() {
        return service.getAll();
    }
    @GetMapping("/{id}")
    public Slot12User getById(@PathVariable String id) {
        return service.getById(id).orElse((null));
    }
    @PostMapping
    public Slot12User create(@RequestBody Slot12User u) {
        return service.create(u);
    }
    @PutMapping("/{id}")
    public Slot12User update(@PathVariable String id, @RequestBody Slot12User u) {
        return service.update(id, u);
    }
    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) {
        service.delete(id);
        return "Deleted id="+id;
    }
}
