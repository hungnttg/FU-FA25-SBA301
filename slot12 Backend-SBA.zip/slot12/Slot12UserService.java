package com.example.t1.slot12;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Slot12UserService {
    @Autowired
    private Slot12UserRepository repo;
    public List<Slot12User> getAll() {
        return repo.findAll();
    }
    public Optional<Slot12User> getById(String id) {
        return repo.findById(id);
    }
    public Slot12User create(Slot12User u) {
        return repo.save(u);
    }
    public void delete(String id) {
        repo.deleteById(id);
    }
    public Slot12User update(String id, Slot12User u) {
        return repo.findById(id).map(user -> {
            user.setName(u.getName());
            user.setBirthday(u.getBirthday());
            return repo.save(user);
        }).orElse(null);
    }
}
