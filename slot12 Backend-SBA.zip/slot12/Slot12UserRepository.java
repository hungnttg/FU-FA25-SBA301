package com.example.t1.slot12;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Slot12UserRepository extends MongoRepository<Slot12User, String> {

}
