package com.example.t1.slot21;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot221/products")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class Slot21ProductController {
    private final Slot21ProductRepository repo;
    @GetMapping
    public List<Slot21Product> getAll() {
        return repo.findAll();
    }
    @PostMapping
    public Slot21Product add(@RequestBody Slot21Product product) {
        return repo.save(product);
    }
    @PutMapping("/{id}")
    public Slot21Product update(@PathVariable Long id, @RequestBody Slot21Product product) {
        product.setId(id);
        return repo.save(product);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
