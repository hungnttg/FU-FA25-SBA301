package com.example.t1.slot21;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface Slot21ProductRepository extends JpaRepository<Slot21Product,Long> {}
