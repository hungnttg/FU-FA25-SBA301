import { useState, useEffect } from "react";

function Slot12App() {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [birthday, setBirthday] = useState("");
  const [editingId, setEditingId] = useState(null);

  const API = "http://localhost:8083/slot12user"; // Spring Boot chạy cổng 8084

  // Lấy tất cả người dùng
  const fetchUsers = async () => {
    try {
      const res = await fetch(API);
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error("Error fetching users:", err);
    }
  };

  useEffect(() => { fetchUsers(); }, []);

  // Thêm / Cập nhật người dùng
  const saveUser = async () => {
    if (!name || !birthday) { alert("Name and birthday required"); return; }
    try {
      if (editingId) {
        await fetch(`${API}/${editingId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, birthday }),
        });
      } else {
        await fetch(API, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, birthday }),
        });
      }
      setName(""); setBirthday(""); setEditingId(null);
      fetchUsers();
    } catch (err) { console.error("Error saving user:", err); }
  };

  // Chỉnh sửa
  const editUser = (u) => {
    setName(u.name);
    setBirthday(u.birthday);
    setEditingId(u.id);
  };

  // Xóa
  const deleteUser = async (id) => { 
    if (!window.confirm("Delete?")) return; 
    await fetch(`${API}/${id}`, { method: "DELETE" }); 
    fetchUsers(); 
  };

  return (
    <div style={{ padding:"20px", maxWidth:"600px", margin:"auto" }}>
      <h2>{editingId ? "Edit Slot12User" : "Add Slot12User"}</h2>
      <input type="text" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} style={{width:"100%",marginBottom:"10px"}}/>
      <input type="date" placeholder="Birthday" value={birthday} onChange={e=>setBirthday(e.target.value)} style={{width:"100%",marginBottom:"10px"}}/>
      <button onClick={saveUser} style={{width:"100%",marginBottom:"20px"}}>{editingId?"Update":"Add"}</button>

      <h2>Slot12User List</h2>
      <table border="1" cellPadding="5" style={{width:"100%"}}>
        <thead><tr><th>ID</th><th>Name</th><th>Birthday</th><th>Actions</th></tr></thead>
        <tbody>
          {users.map(u=>(
            <tr key={u.id}>
              <td>{u.id}</td>
              <td>{u.name}</td>
              <td>{u.birthday}</td>
              <td>
                <button onClick={()=>editUser(u)}>Edit</button>{" "}
                <button onClick={()=>deleteUser(u.id)}>Delete</button>
              </td>
            </tr>
          ))}
          {users.length===0 && <tr><td colSpan="4" style={{textAlign:"center"}}>No users</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

export default Slot12App;
