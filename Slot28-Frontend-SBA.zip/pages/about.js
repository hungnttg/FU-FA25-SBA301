export default function About(){
    return(
        <div>
            <h2>About us</h2>
            <p>This website is bulit with next</p>
        </div>
    );
}