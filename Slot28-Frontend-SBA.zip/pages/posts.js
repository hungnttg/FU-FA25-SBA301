//pages/posts.js
//toi uu load trang bang statc generation + ISR (chi load 1 phan du lieu, khong load toan bo)
export async function getStaticProps(){//load tinh
    const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=5');
    const posts = await res.json();//chuyen ket qua sang json
    return {
        props: {posts},
        revalidate: 60, // tai lai sau 60s, chi tai nhung thanh phan co data thay doi
    };
}
export default function PostsPage({posts}){
    return(
        <main style={{padding:20}}>
            <h1>Danh sach bai viet</h1>
            <ul>
                {posts.map(p=>(
                    <li key={p.id}>
                        <strong>{p.title}</strong>
                        <p>{p.body}</p>
                    </li>
                ))}
            </ul>
        </main>
    );
}