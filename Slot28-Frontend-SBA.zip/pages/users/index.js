"use client";
import { useEffect,useState } from "react";
export default function UsersPage(){
    const [users,setUsers]=useState([]);
    const [form,setForm]=useState({name:"",email:""});
    useEffect(()=>{
        fetch("http://localhost:8083/slot28/api/users")
        .then(res=>res.json())
        .then(data=>setUsers(data))
        .catch(err => console.error(err));
    },[]);
    const handleSubmit = async (e) =>{
        e.preventDefault();
        const res = await fetch("http://localhost:8083/slot28/api/users",{
            method: "POST",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify(form),
        });
        const newUser = await res.json();
        setUsers([...users, newUser]);
        setForm({name:"",email:""});
    };
    return(
        <div style={{padding:20}}>
            <h1>Sanh sach nguoid dung</h1>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Ten"
                    value={form.name}
                    onChange={(e)=>setForm({...form,name:e.target.value})}
                />
                <input
                    type="email"
                    placeholder="Email"
                    value={form.email}
                    onChange={(e)=>setForm({...form,email:e.target.value})}
                    required
                />
                <button type="submit">Them</button>
            </form>
            {/* hien thi du lieu */}
            <ul>
                {users.map(u=>(
                    <li key={u.id}>
                        {u.name}  - {u.email}
                    </li>
                ))}
            </ul>
        </div>
    );
}