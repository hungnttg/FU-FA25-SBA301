package com.example.t1.slot22;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/slot222/products")
public class Slot21ProductController {
    private List<Slot22Product> products = List.of(
            new Slot22Product(1,"Iphone 17",1200),
            new Slot22Product(2,"Samsung S27",1000),
            new Slot22Product(3,"Xiaomi 15",789)
    );
    @GetMapping
    public List<Slot22Product> getAll() {
        return products;
    }
}
