package com.example.t1.slot22;

import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/slot222/order")
public class Slot21OrderController {
    @GetMapping("/create/{id}")
    public String createOrder(@PathVariable int id) {
        return "Slot22: Don hang cho san pham ID "+id+" duoc tao";
    }
}
