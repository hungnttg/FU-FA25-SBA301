package com.example.t1.slot28;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot28Application {
    public static void main(String[] args) {
        SpringApplication.run(Slot28Application.class, args);
    }
}
