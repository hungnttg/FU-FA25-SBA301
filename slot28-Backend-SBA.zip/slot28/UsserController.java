package com.example.t1.slot28;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/slot28/api/users")
public class UsserController {
    private final UserRepository repo;
    public UsserController(UserRepository repo) {
        this.repo = repo;
    }
    @GetMapping
    public List<User> getAll() {
        return repo.findAll();
    }
    @PostMapping
    public User addUser(@RequestBody User user) {
        return repo.save(user);
    }
}
