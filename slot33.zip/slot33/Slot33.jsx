import React,{useState,useCallback,useTransition, Suspense,lazy} from "react";
import Counter from "./Counter";
import ExpensiveList from "./ExpensiveList";
import LoadingSpinner from "./LoadingSpinner";
//Lazy load mot component vi du
const LazyComponent = lazy(()=> import('./LoadingSpinner'));
function Slot33(){
    const [count,setCount]=useState(0);
    const [items,setItems]=useState([]);
    //useTransititon de thao tac nang ma khong can block UI
    const [isPending, startTransition]=useTransition();
    //useCallback giup ham khong bi tao lai khi render lai
    const handleIncrement = useCallback(()=>{
        setCount(prev => prev +1);
    },[]);
    //tinh toan nang
    const handleAddItems = () =>{
        startTransition(()=>{
            const newItems = Array.from({length:1000},(_,i) => `Items ${i+1}`);
            setItems(newItems);
        });
    };
    //giao dien
    return(
        <div style={{padding:'20px'}}>
            <h1>React Advanced</h1>
            {/* React.memo + useCallback */}
            <Counter count={count} onIncrement={handleIncrement}/>
            <hr/>
            {/* useTransition + useMemo trong ExpensiveList */}
            <button onClick={handleAddItems}>
                Add 1000 items (Thao tac tinh toan nang)
            </button>
            {isPending && <p>Updating list...</p>}
            <ExpensiveList items={items} />
            <hr/>
            {/* Lazy Load component */}
            <Suspense fallback={<LoadingSpinner/>}>
                <LazyComponent/>
            </Suspense>
        </div>
    );
}
export default Slot33;