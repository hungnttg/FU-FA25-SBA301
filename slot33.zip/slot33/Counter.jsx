import React from "react";
//su dung memo giup component nay chi render lai khi props thay doi
const Counter = React.memo(({count,onIncrement})=>{
    console.log('Render Counter');
    return(
        <div>
            <h2>Counter: {count}</h2>
            <button onClick={onIncrement}>Increment</button>
        </div>
    );
});
export default Counter;