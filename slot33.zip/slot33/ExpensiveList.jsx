import React,{useMemo} from "react";
//Gia lap danh sach tinh toan nang
const ExpensiveList = ({items}) =>{
    console.log('Render ExpensiveList');
    //useMemo giup tinh toan chi khi items thay doi
    const renderedList = useMemo(()=>{
        return items.map((item,index)=> <li key={index}>{item}</li>);
    },[items]);
    return(
        <div>
            <h3>Expensive List</h3>
            <ul>{renderedList}</ul>
        </div>
    );
};
export default ExpensiveList;