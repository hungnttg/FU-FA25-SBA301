package com.example.t1.slot11;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot11UserRepository extends JpaRepository<Slot11User, Long> {
}
