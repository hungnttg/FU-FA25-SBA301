package com.example.t1.slot11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot11SpringBootDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(Slot11SpringBootDemoApplication.class, args);
    }
}
