import Header from "./slot16/Header";
import Footer from "./slot16/Footer";
import Content1 from "./slot16/Content1";
import Content2 from "./slot16/Content2";
import "./App.css";
export default function App(){
  return(
    <div className="app-container">
      <Header/>
      <main className="main-content">
        <Content1/>
        <Content2/>
      </main>
      <Footer/>
    </div>
  );
}