import React,{useEffect,useState} from "react";
import "./Content1.css";
export default function Content1(){
    const [products,setProducts]=useState([]);
    const [visible,setVisible]=useState(6);//cho 6 san pham hien thi
    useEffect(()=>{
        fetch("https://hungnttg.github.io/shopgiay.json")
        .then((res)=>res.json())
        .then((data)=>{
            if(data && Array.isArray(data.products)){
                setProducts(data.products);
            }
            else {
                console.error("Loi: ",data);
            }
        })
        .catch((err)=>console.error("Error fetching data: ",err));
    },[]);
    const loadMore = () => setVisible((prev)=> prev + 6);
    return(
        <section className="content-box">
            <h2>Content Setion 1</h2>
            <div className="grid">
                {Array.isArray(products) && products.slice(0,visible).map((item)=>(
                    <div key={item.styleid} className="card">
                        <img src={item.search_image} />
                        <h3>{item.brands_filter_facet}</h3>
                        <p>{item.product_additional_info}</p>
                        <p><strong>Price: </strong>{item.price}d</p>
                    </div>
                ))}
            </div>
            {Array.isArray(products) && visible < products.length && (
                <button className="load-more" onClick={loadMore}>Load More</button>
            )}
        </section>
    );
  
}