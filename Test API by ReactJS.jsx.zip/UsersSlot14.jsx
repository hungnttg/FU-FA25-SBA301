//cách chạy API từ ReactJS
//b1: cài npm i -g http-server
//b2: chạy server ở công 3000 mà không cần có web
//http-server -p 3000
//b3: vao trình duyệt gõ http://localhost:3000 thì sẽ hiển thị trang trắng
//b4: nhấn phải chuột -> chọn Inspect -> chọn Console -> paste đoạn code dưới đây 
//cuối cùng enter
//=============
//copy vao phan console cua localhost:3000
//test API version 1
fetch("http://localhost:8083/slot14/users",{
    headers: {"X-API-VERSION":"1"}
})
.then(res=>res.json())
.then(data=>console.log("V1:",data))
.catch(err=>console.error("Error V1: ",err));
//----
//Version 2
fetch("http://localhost:8083/slot14/users",{
    headers: {"X-API-VERSION":"2"}
})
.then(res=>res.json())
.then(data=>console.log("V2:",data))
.catch(err=>console.error("Error V2: ",err));