// npm i dotenv
// npm i express
// npm i body-parser
// npm i child_process
// npm i path
require("dotenv").config();
const express = require("express");
const bodyParser = require("body-parser");
const {exec} = require("child_process");
const path = require("path");
const app = express();
app.use(bodyParser.json());
app.use(express.static("public"));
//doc cau hinh thu env
const PDF_FOLDER = process.env.PDF_FOLDER;
const GEMINI_API_KEY=process.env.GEMINI_API_KEY;
//API: nhan cau tra loi tu client, goi Python xu ly PDF+ gemini
app.post("/ask",(req,res)=>{
    const question = req.body.question;
    //goi python
    exec(`python3 rag_service.py "${PDF_FOLDER}" "${question}" "${GEMINI_API_KEY}"`,
        {cwd: __dirname,maxBuffer: 1024 * 1024 * 10},
        (error,stdout,stderr) =>{
            if(error){
                console.error("Loi: ",stderr);
                return res.status(500).json({answer: "Loi khi xu ly yeu cau"});
            }
            res.json({answer: stdout.trim()});
        }
    );
});
//server lang nghe
const PORT=3000;
app.listen(PORT,()=>{
    console.log(`Server dang cahy tai http://localhost:${PORT}`);
});

