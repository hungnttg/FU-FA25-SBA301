"use client";
import { useState } from "react";
//npm i dompurify
import DOMPurify from "dompurify";
export default function XSSSafe(){
    const [comment,setComment]=useState("");
    return(
        <div>
            <h2>Binh luan an toan</h2>
            <input
                type="text"
                placeholder="nhap binh luan..."
                onChange={(e)=>setComment(e.target.value)}
            />
            <p>Hien thi binh luan</p>
            {/* lam sach du lieu truoc khi render bang DOMPurify */}
            <div dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(comment),
            }} />
        </div>
    );
}