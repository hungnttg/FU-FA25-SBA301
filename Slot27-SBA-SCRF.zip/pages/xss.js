//cho phep nguoi dung comment khong an toan
"use client";
import { useState } from "react";
export default function XSSBad(){
    const [comment,setComment]=useState("");
    return(
        <div>
            <h2>Binh luan KHONGan toan</h2>
            <input
                type="text"
                placeholder="Nhap binh luan..."
                onChange={(e)=>setComment(e.target.value)}
            />
            <p>Hien thi binh luan</p>
            {/* de bi hack bang XSS neu nhap */}
            {/* <img src=x oneror="alert(1)"> */}
            {/* trang se tu chay bang ma cua hacker */}
            <div dangerouslySetInnerHTML={{__html: comment}}/>
        </div>
    );
}