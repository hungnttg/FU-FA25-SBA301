import Link from "next/link";
import { useEffect,useState } from "react";
export default function Blog(){
    const [posts,setPosts]=useState([]);
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts")
        .then((res)=>res.json())
        .then((data)=>setPosts(data.slice(0,10)));//lay 10 bai post
    },[]);
    return(
        <div>
            <h2>Blog Posts</h2>
            <ul>
                {posts.map((post)=>(
                    <li key={post.id}>
                        <Link href={`/blog/${post.id}`}>{post.title}</Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}