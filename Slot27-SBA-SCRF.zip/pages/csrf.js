export default function CSRF(){
    const handleSubmit = async (e) =>{
        e.preventDefault();//chong gui du lieu mac dinh (reload trang)
        const res = await fetch("/api/submit",{
            method: "POST",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify({csrfToken: "123457"}),
            //doi token xem co chay khoong????
        });
        alert((await res.json()).message);
    };
    return(
        <div style={{padding:40}}>
            <h3>Demo CSRF don gian</h3>
            <form onSubmit={handleSubmit}>
                <button type="submit">Gui du lieu</button>
            </form>
        </div>
    );
}