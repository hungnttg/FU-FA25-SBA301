export default function Home(){
    return(
        <div>
            <h2>Welcome to my website</h2>
            <p>This is the Homepage content</p>
        </div>
    );
}