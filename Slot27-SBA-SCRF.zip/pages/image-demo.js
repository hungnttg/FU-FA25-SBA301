import Image from "next/image";
export default function ImageDemo(){
    return(
        <main style={{padding:20}}>
            <h1>Demo toi uu hinh anh</h1>
            <Image
                src="https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d"
                alt="Canh thien nhien"
                width={400}
                height={600}
                quality={80}
                priority
                style={{borderRadius:'15px'}}
            />
            <p>Anh nay duoc nen, responsive, lazy load tu dong</p>
        </main>
    );
}