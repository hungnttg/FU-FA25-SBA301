//pages/api/submit.js
export default function handler(req,res){
    if(req.method === "POST"){
        if(req.body.csrfToken !== "123456"){
            return res.status(403).json({message: "CSRF khong dung token"});
        }
        return res.status(200).json({message: "Thanh cong"});
    }
    res.status(405).end();
}