import Layout from "@/components/layout";
//co the import css o day neu co
export default function MyApp({Component,pageProps}){
    return(
        <Layout>
            <Component {...pageProps} />
        </Layout>
    );
}