//components/layout.js
import Link from "next/link";
import React from "react";
import { useState } from "react";
export default function Layout({children}){
    const [show,setShow]=useState(false);
    return(
        <div style={{fontFamily:"Arial, sans-serif"}}>
            <header style={{padding:"10px",backgroundColor:"#AA11"}}>
                <nav style={{display:"flex", gap:"20px",position:"relative"}}>
                    <Link href="/">Home</Link>
                    <Link href="/about">About</Link>
                    <Link href="/blog">Blog</Link>
                    <div
                        onMouseEnter={()=>setShow(true)}
                        onMouseLeave={()=>setShow(false)}
                        style={{position:"relative",cursor:"pointer"}}
                    >
                        Items
                        {show && (
                            <ul style={{position:"absolute",top:"100%",left:0,
                                background:"#eee", listStyle:"none",margin:0
                            }}>
                                <li style={{padding:"5px 10px"}}>
                                    <Link href="/items/item1">Item1</Link>
                                </li>
                                <li style={{padding:"5px 10px"}}>
                                    <Link href="/items/item2">Item2</Link>
                                </li>
                            </ul>
                        )}
                    </div>
                    <Link href="/posts">Posts</Link>
                    <Link href="/chart">Chart</Link>
                    <Link href="/prefetch-demo">Prefetch Demo</Link>
                    <Link href="/image-demo">Image Demo</Link>
                    <Link href="/xss">XSS Bad</Link>
                    <Link href="/xss-safe">XSS Safe</Link>
                    <Link href="/csrf">CSRF</Link>
                </nav>
            </header>
            <main style={{padding:"20px"}}>{children}</main>
            <footer style={{padding:"10px", backgroundColor:"#ff11",marginTop:"20px"}}>
                &copy; 2025 my website
            </footer>
        </div>
    );
}