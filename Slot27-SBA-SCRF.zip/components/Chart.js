//component/Chart.js
//component nang
export default function Chart(){
    return(
        <div style={{marginTop:20, padding:20, background:"#aabb"}}>
            <h2>Bieu do da duoc tai</h2>
            <p>Day la component nang, chi tai khi can thiet</p>
        </div>
    );
}