import React,{useState,useEffect} from "react";
export default function Slot22(){
    const [products,setProducts]=useState([]);
    const [message,setMessage]=useState("");
    useEffect(()=>{
        fetch("http://localhost:8083/slot222/products")
        .then(res=>res.json()) //chuyen sang json
        .then(data=>setProducts(data))//update product
        .catch(()=> setMessage("Khong the tai danh sach san pham"));
    },[]);
    const createOrder = (id) =>{
        fetch(`http://localhost:8083/slot222/orders/create/${id}`)
        .then(res=>res.text())
        .then(text =>setMessage(text))
        .catch(()=>setMessage("Loi khi tao don hang"));
    };
    //giao dien
    return(
        <div style={{padding:20}}>
            <h1>Slot22 shop</h1>
            {products.map(p=>(
                <div key={p.id} style={{border:"1px solid grey", margin:"10px", padding:"10px"}}>
                    <h3>{p.name}</h3>
                    <p>Gia: {p.price}</p>
                    <button onClick={()=>createOrder(p.id)}>Dat hang</button>
                </div>
            ))}
            {message && <p style={{color:"green"}}>{message}</p>}
        </div>
    );
}