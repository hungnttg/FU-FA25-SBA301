//bai toan gio hang
//cai thu vien
//npm i @reduxjs/toolkit react-redux
import React from "react";
import { configureStore, createSlice } from "@reduxjs/toolkit";
import { Provider, useDispatch, useSelector } from "react-redux";
//gio hang
const cartSlice = createSlice({
    name:"cart",
    initialState:{
        items:[],//sanh sach san pham
    },
    reducers:{
        addItem: (state,action) => {
            state.items.push(action.payload);//them san pham
        },
        removeItem: (state,action) => {
            state.items = state.items.filter((item)=>item.id !== action.payload);//xoa
        },
        clearCart: (state) =>{
            state.items = [];//xoa het gio hang
        },
    },
});
//dinh nghia kho trang thai
const store =configureStore({reducer: cartSlice.reducer});//truyen cac state vao kho
const {addItem,removeItem,clearCart} = cartSlice.actions;//khai bao action lien ket
//tao giao duen cho nguoi dung thao tacs
function CartUI(){
    const items = useSelector((state) => state.items);//lua chon trang thai
    const dispatch = useDispatch();//phan phoi trang thai
    //danh sach san pham//sau nay dung API de doc san pham o day
    const sampleProducts = [
        {id:1,name:"Tao"},
        {id:2,name:"Cam"},
        {id:3,name:"Xoai"}
    ];
    //giao dien hien thi
    return(
        <div style={{padding:20}}>
            <h1>Gio hang</h1>
            <h2>San pham co san</h2>
            {sampleProducts.map((product)=>(
                <div key={product.id}>
                    {product.name}{" "} 
                    <button onClick={()=>dispatch(addItem(product))}>Them vao Cart</button>
                </div>
            ))}
            <h2>Danh sach san pham trong gio hang</h2>
            {items.length === 0 ? (
                <p>Chua co san pham nao</p>
            ):(
                <ul>
                    {items.map((item)=>(
                        <li key={item.id}>
                            {item.name}{" "}
                            <button onClick={()=>dispatch(removeItem(item.id))}>Xoa</button>
                        </li>
                    ))}
                </ul>
            )}
            {items.length >0 && (
                <button onClick={()=>dispatch(clearCart())}>Clear All</button>
            )}
        </div>
    );
};
export default function Cart(){
    return(
        <Provider store={store}>
            <CartUI/>
        </Provider>
    );
}