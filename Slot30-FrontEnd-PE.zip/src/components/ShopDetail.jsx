import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
export default function ShopDetail(){
    const {id} =useParams();
    const [shop,setShop]=useState({});
    useEffect(()=>{
        axios.get(`http://localhost:8083/slot29/shops/${id}`)
        .then(res=>setShop(res.data));
    },[id]);
    return(
        <div className="container mt-3">
            <h3>View</h3>
            <p>{shop.shopName}</p>
            <p>{shop.type}</p>
            <p>{shop.owner}</p>
            <p>{shop.openTime}</p>
        </div>
    );
}