//npm create vite@latest PE --template react
//npm i react-bootstrap bootstrap axios react-router-dom
import { useEffect,useState } from "react";
import {useNavigate} from "react-router-dom";
import {Modal,Form,Button,Table} from "react-bootstrap";
import axios from "axios";
export default function ShopList(){
    const [shops,setShops]=useState([]);
    const [form,setForm]=useState({shopName:"",owner:"",type:"",openTime:""});
    const [show,setShow]=useState(false);
    const [types,setTypes]=useState([]);
    const [deleteId,setDeleteteId]=useState(null);
    const navigate = useNavigate();
    const API = "http://localhost:8083/slot29/shops";
    useEffect(()=>{
        loadData();
        axios.get("http://localhost:8083/slot29/shops/types")
        .then(res=>setTypes(res.data));
    },[]);
    const loadData=() => axios.get(API).then(res=>setShops(res.data));
    const handleAdd = () =>{
        if(!form.shopName || !form.type || !form.owner || !form.openTime){
            alert("moi nhap du du lieu");
            return;
        }
        axios.post(API,form).then(()=>{
            alert("Them thanh cong");
            loadData();
        });
    };
    const handleXoa = () =>{
        axios.delete(`${API}/${deleteId}`).then(()=>{
            alert("Xoa thanh cong");
            setShow(false);
            loadData();
        });
    };
    const confirmXoa = (id) =>{
        setDeleteteId(id);
        setShow(true);
    };
    return(
        <div className="container mt-3">
            <h2>Book Shop Management</h2>
            {/* form nhap lieu */}
            <Form className="mb-3">
                <Form.Control
                    placeholder="Shop name"
                    value={form.shopName}
                    onChange={(e)=>setForm({...form,shopName: e.target.value})}
                    className="mb-2"
                />
                <Form.Control
                    placeholder="Owner"
                    value={form.owner}
                    onChange={(e)=>setForm({...form,owner: e.target.value})}
                    className="mb-2"
                />
                <Form.Select
                    value={form.type}
                    onChange={(e)=>setForm({...form,type: e.target.value})}
                    className="mb-2"
                    >
                    <option value="">Select Type</option>
                    {types.map(t=> <option key={t}>{t}</option>)}
                </Form.Select>
                <Form.Control
                    placeholder="Open time"
                    type="number"
                    value={form.openTime}
                    onChange={(e)=>setForm({...form,openTime:e.target.value})}
                    className="mb-2"
                />
                <Button onClick={handleAdd}>Add New</Button>
            </Form>
            <Table bordered>
                <thead>
                    <tr>
                        <th>#No</th>
                        <th>Shop Name</th>
                        <th>Type</th>
                        <th>Owner</th>
                        <th>OpenTime</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {shops.map((s,i)=>(
                        <tr key={s.id}>
                            <td>{i+1}</td>
                            <td>{s.shopName}</td>
                            <td>{s.type}</td>
                            <td>{s.owner}</td>
                            <td>{s.openTime}</td>
                            <td>
                                <Button variant="danger" size="sm" onClick={()=>confirmXoa(s.id)}>Delete</Button>{" "}
                                <Button variant="info" size="sm" onClick={()=>navigate(`/view/${s.id}`)}>View</Button>{" "}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
            <Modal show={show} onHide={()=>setShow(false)}>
                <Modal.Header closeButton><Modal.Title>Confirmation</Modal.Title></Modal.Header>
                <Modal.Body>Ban co chac chan xoa khong?</Modal.Body>
                <Modal.Footer>
                    <Button onClick={handleXoa}>Yes</Button>
                    <Button variant="secondary" onClick={()=>setShow(false)}>Close</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}
