import React from "react";
import styled, {} from 'styled-components';
export default function Slot24_1(){
    // css
    const Button = styled.button`
            background: blue;
            color: white;
            padding: 10px 20px;
            border-radius:  10px;

            &:hover {
                background: green;
            }
    `;
    //layiut
    return(
        <div>
            <Button>Click Me</Button>
        </div>
    );
}