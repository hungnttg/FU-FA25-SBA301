import React,{useState,useEffect} from "react";
import styled, {} from "styled-components";
//css
const Container = styled.div`
            padding: 40px;
            display: grid;
            text-wrap: wrap;
            grid-template-columns: repeat(4,1fr);
`;
const Card=styled.div`
            padding:2px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            background: white;
            width: 250px;
            border-radius: 10ox;
            overflow: hidden;
            transition: transform 0.2s;
            &:hover {
                transform: translateY(-5px);
            }
`;
const ProductImage = styled.img`
    width:100%;
    heigh:250px;
    object-fit: cover;
`;
const ProductInfo=styled.div`
    padding:20px;
`;
const Brand=styled.div`
    color:#555
`;
const Name=styled.div`
    font-size:20px;
    color: #333
`;
const Price=styled.div`
    font-size:20px;
    color: #333
`;
export default function Slot34_3(){
    const [products,setProducts]=useState([]);
    useEffect(()=>{
        fetch('https://hungnttg.github.io/shopgiay.json')
        .then(res=>res.json())
        .then(data =>setProducts(data.products || []))
        .catch(err=>console.error("Loi doc du lieu: ",err));
    },[]);
    return(
        <Container>
            {products.map(product=>(
                <Card key={products.styled}>
                    <ProductImage src={product.search_image}/>
                    <ProductInfo>
                        <Brand>{product.brands_filter_facet}</Brand>
                        <Name>{product.product_additional_info}</Name>
                        <Price>{product.price.toLocaleString()}</Price>
                    </ProductInfo>
                </Card>
            ))}
        </Container>
    );
}