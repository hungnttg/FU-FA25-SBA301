import styled, {} from 'styled-components';
const Button = styled.button`
    background: ${props=>props.primary ? "blue":"gray"};
    color: white;
    padding: 15px 15px;
    border: none;
    color: white;
            padding: 15px 15px;
            border: none;
            border-radius: 5px;
            margin: 5px;
            cursor: pointer;
`;
export default function Slot24_2(){
    return(
        <div>
            <Button primary>Primary</Button>
            <Button>Detail</Button>
        </div>
    );
}