import React,{useEffect,useState} from "react";
export default function D8_1(){
    //code
    const [products,setProducts]=useState([]);
    const [loading,setLoading]=useState(true);
    const fetchProducts = () =>{
        fetch("http://localhost:8083/api/products")
        .then(res => res.json()) //tra ve json
        .then(data => {
            setProducts(data); //cap nhat du lieu vao state products
            setLoading(false); //dung trang thai loading
        })
        .catch(console.error);
    };
    //su dung useEffect
    useEffect(()=> fetchProducts(),[]);
    //xoa du lieu
    const deleteProduct = (id) => {
        fetch(`http://localhost:8083/api/products/${id}`,{method:"DELETE"})
        .then(()=>fetchProducts()) //cap nhat lai sau khi xoa
        .catch(console.error);
    };
    if(loading) return <div>Dang tai...</div>;
    //layout
    return(
        <div style={{padding:20}}>
            <h1>Danh sach san pham</h1>
            <div style={{display:"flex",flexWrap:"wrap"}}>
                {products.map(p => (
                    <div key={p.id} style={{width:260, border: "1px solid #bbb", 
                        borderRadius:5, padding:10, margin:8}}>
                            <img src={p.hinhanhsanpham} style={{width:"100%", height:120,
                                objectFit:"cover"}} />
                            <h3>{p.tensanpham} VND</h3>
                            <p>Gia: {p.giasanpham}</p>
                            <button onClick={()=>deleteProduct(p.id)}
                                style={{background:"red",color:"white"}}
                                >Xoa</button>
                    </div>
                ))}
            </div>
        </div>
    );

}