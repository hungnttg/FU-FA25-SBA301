import React from "react";
const Contact = () =>{
    return(
        <div>
            <h1>Contact Page</h1>
            <p>Day la trang lazy load</p>
        </div>
    );
};
export default Contact;