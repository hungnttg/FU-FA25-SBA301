import { useState, useEffect } from "react";

function D10_1() {
  const [user, setUser] = useState(null);
  const [name, setName] = useState("");
  const [birthday, setBirthday] = useState("");

  // Lấy user từ Spring Boot
  const fetchUser = async () => {
    try {
      const res = await fetch("http://localhost:8083/user");
      const data = await res.json();
      setUser(data);
    } catch (err) {
      console.error("Error fetching user:", err);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  // Gửi user mới lên Spring Boot
  const createUser = async () => {
    if (!name || !birthday) {
      alert("Please fill in all fields");
      return;
    }
    try {
      const res = await fetch("http://localhost:8083/user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, birthday }),
      });
      const text = await res.text();
      alert(text);
      setName("");
      setBirthday("");
      fetchUser(); // cập nhật user
    } catch (err) {
      console.error("Error creating user:", err);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Slot10 Jackson Spring Boot Demo</h1>

      <div style={{ marginBottom: "20px" }}>
        <h2>Current User</h2>
        {!user ? (
          <p>Loading...</p>
        ) : (
          <div>
            <p><strong>Name:</strong> {user.name}</p>
            <p><strong>Birthday:</strong> {user.birthday}</p>
          </div>
        )}
      </div>

      <div>
        <h2>Create New User</h2>
        <input
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        /><br />
        <input
          placeholder="Birthday (dd-MM-yyyy)"
          value={birthday}
          onChange={(e) => setBirthday(e.target.value)}
        /><br />
        <button onClick={createUser}>Submit</button>
      </div>
    </div>
  );
}

export default D10_1;
