import React,{useState,useEffect} from "react";
import axios from "axios";
export default function Slot34(){
    //khai bao bien
    const [students,setStudents]=useState([]);
    const [form,setForm]=useState({name:'',email:''});
    //ham load
    useEffect(()=>{
        axios.get('http://localhost:8083/api/students')
        .then(res=>setStudents(res.data))
        .catch(console.error);
    },[]);
    //cac ham khac
    const handleSubmit = e => {
        e.preventDefault();//cam reload mac dinh
        axios.post('http://localhost:8083/api/students',form)
        .then(res=>setStudents([...students,res.data]))
        .then(()=>setForm({name:'',email:''}))
        .catch(console.error);
    };
    const handleDelete = id =>{
        axios.delete(`http://localhost:8083/api/students/${id}`)
        .then(()=>setStudents(students.filter(s => s.id !== id)))
        .catch(console.error);
    };
    //giao dien
    return(
        <div style={{width:400, margin:'auto',textAlign:'center'}}>
            <h2>Student Management</h2>
            <form onSubmit={handleSubmit}>
                <input
                    placeholder="Name"
                    value={form.name}
                    onChange={e=>setForm({...form,name: e.target.value})}
                    required
                />
                <input
                    placeholder="Email"
                    value={form.email}
                    onChange={e=>setForm({...form,email: e.target.value})}
                    required
                />
                <button type="submit">Add</button>
            </form>
            {/* tao table de hien thi du lieu */}
            <table border="1" width="100%" style={{marginTop:20}}>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {students.map(s=>(
                        <tr key={s.id}>
                            <td>{s.id}</td>
                            <td>{s.name}</td>
                            <td>{s.email}</td>
                            <td>
                                <button onClick={()=>handleDelete(s.id)}>
                                    Xoa
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}