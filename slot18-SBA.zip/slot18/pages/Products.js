import { Link } from "react-router-dom";
export default function Products(){
    //du lieu
    const list=[
        {id:1,name:"Laptop DEL"},
        {id:2,name:"Macbook pro"},
        {id:3,name: "Asus zenbook"}
        ];
        //layout
        return(
            <div className="container">
                <h2>Danh sachs san pham</h2>
                <ul>
                    {list.map(p=>(
                        <li key={p.id}>
                            <Link to={`/products/${p.id}`}>{p.name}</Link>
                        </li>
                    ))}
                </ul>
            </div>
        );
    
}