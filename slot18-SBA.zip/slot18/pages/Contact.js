export default function Contact(){
    return(
        <div className="container">
            <h2>Lien he</h2>
            <p>email: contact@gmail.com</p>
            <p>Mobile: 0912345678</p>
        </div>
    );
}