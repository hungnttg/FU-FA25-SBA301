import { useState,useEffect } from "react";
import {Link} from "react-router-dom";
export default function Posts(){
    //code
    const [posts,setPosts]=useState([]);
    const [loading,setLoading]=useState(true);
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts?_limit=10")
        .then(res=>res.json())
        .then(data=>{
            setPosts(data);
            setLoading(false);
        });
    },[]);
    if(loading) return <p>Dang tai bai viet...</p>
    //layout
    return(
        <div className="container">
            <h2>Danh sach bai viet</h2>
            {posts.map(post=>(
                <div key={post.id} className="card">
                    <h3>{post.title}</h3>
                    <p>{post.body.slice(0,80)}...</p>
                    <Link to={`/posts/${post.id}`}>
                        <button>Xem chi tiet</button>
                    </Link>
                </div>
            ))}
        </div>
    );
}