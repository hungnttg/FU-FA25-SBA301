import "./App5.css";
import { Link, Route, BrowserRouter as Router, Routes } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import Posts from "./pages/Posts";
import PostDetail from "./pages/PostDetail";
export default function App5(){
    return(
        <Router>
            <nav>
                <Link to={"/"}>Home</Link>
                <Link to={"/about"}>Gioi thieu</Link>
                <Link to={"/contact"}>Lien he</Link>
                <Link to={"/products"}>San pham</Link>
                <Link to={"/posts"}>Bai viet</Link>
            </nav>
            <Routes>
                <Route path="/" element={<Home/>}/>
                <Route path="/about" element={<About/>}/>
                <Route path="/contact" element={<Contact/>}/>
                <Route path="/products" element={<Products/>}/>
                <Route path={"/products/:id"} element={<ProductDetail/>}/>
                <Route path="/posts" element={<Posts/>}/>
                <Route path="/posts/:id" element={<PostDetail/>}/>
            </Routes>
        </Router>
        
    );
}