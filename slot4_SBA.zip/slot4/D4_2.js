//su dung Card
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
function D4_2(){
    return(
        <div style={{padding:"20px"}}>
            <Card style={{width: '20rem'}}>
                <Card.Img variant="top" src='https://placehold.co/200' style={{margin: "2px"}} />
                <Card.Body>
                    <Card.Title>Cart Title</Card.Title>
                    <Card.Text>
                        Day la noi dung mo ta trong card
                    </Card.Text>
                    <Button variant="primary">Primary</Button>{' '}
                </Card.Body>
            </Card>
             
        </div>
    );
}
export default D4_2;