//hien thi dang Grid
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import 'bootstrap/dist/css/bootstrap.min.css';
function D4_3(){
    return(
        <Container>
            <h1 className="mt-3">Demo grid system</h1>
            <Row>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 1</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 2</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 3</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 4</Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}
export default D4_3;
