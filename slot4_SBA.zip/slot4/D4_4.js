//hien thi danh sach san pham don gian
function D4_4(){
    //code
    const students = [
        {id:1,name:"Lan",age: 21},
        {id:2,name:"Yen",age:20},
        {id:3,name:"Hai",age:22},
    ];
    //layout
    return(
        <div>
            <h1>Danh sach SV</h1>
            {students.map((s)=>(
                <div key={s.id}>
                    <p>{s.name} - {s.age}</p>
                </div>
            ))}
        </div>      
    );
}
export default D4_4;