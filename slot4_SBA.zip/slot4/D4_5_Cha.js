import D4_5_Con from "./D4_5_Con";//import thanh phan con
function D4_5_Cha(){
    //code//sau nay se thay mang boi API Spring Boot
        const products = [
            {id:1,name:"Laptop",price:1000,desc:"Laptop gaming"},
            {id:2,name:"Dien thoai",price:150,desc:"Smartphone cao cap"},
            {id:3,name:"Tai nghe",price:12,desc:"Tai nghe bluetooth"},
        ];
    //layout//goi thanh phan con va truyen props
    return(
        <div>
            <h1>Danh sach san phame</h1>
            {products.map((p)=>(
                <D4_5_Con key={p.id} name={p.name} price={p.price} desc={p.desc}/>
            ))}
        </div>
    );
}
export default D4_5_Cha;