//cai dat: npm install react-bootstrap bootstrap
//su dung button
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
function D4_1(){
    return(
        <div style={{padding:"20px"}}>
            <h1>Demo react-bootstrap button</h1>
            <Button variant="primary">Primary</Button>{' '}
            <Button variant="success">success</Button>{' '}
            <Button variant="danger">danger</Button>{' '}
        </div>
    );
}
export default D4_1;