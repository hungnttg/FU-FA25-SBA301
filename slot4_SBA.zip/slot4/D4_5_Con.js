//hien thi danh sach san pham, su dung props
function D4_5_Con({name,price,desc}){
    return(
        <div>
            <h3>{name}</h3>
            <p>Gia: {price}</p>
            <p>{desc}</p>
        </div>
    );
}
export default D4_5_Con;