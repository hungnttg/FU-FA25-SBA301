package com.example.t1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
