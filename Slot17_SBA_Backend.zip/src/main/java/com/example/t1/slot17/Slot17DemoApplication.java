package com.example.t1.slot17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot17DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(Slot17DemoApplication.class, args);
    }
}
