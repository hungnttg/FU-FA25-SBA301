package com.example.t1.slot13;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/slot13/users")
@CrossOrigin(origins = "http://localhost:3000")
public class Slot13UserControllerHeader {
    @GetMapping(headers = "X-API-VERSION=1")
    public List<Slot13User> getUsersV1() {
        return Arrays.asList(
                new Slot13User(1L,"An","An@gmail.com"),
                new Slot13User(2L,"Binh","Binh@gmail.com")
        );
    }
    @GetMapping(headers = "X-API-VERSION=2")
    public List<Slot13User> getUsersV2() {
        return Arrays.asList(
          new Slot13User(1L,"AN","AN@GMAIL.COM"),
          new Slot13User(2L,"BINH","BINH@GMAIL.COM")
        );
    }
}
