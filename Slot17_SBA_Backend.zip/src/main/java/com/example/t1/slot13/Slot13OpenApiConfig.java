package com.example.t1.slot13;

import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.OpenAPI;
import org.springframework.context.annotation.Bean;

public class Slot13OpenApiConfig {
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info().title("Slot 13 API")
                        .version("1.0")
                        .description("Vi du ve Spring Boot API with Verisoning"));
    }
}
