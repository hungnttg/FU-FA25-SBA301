package com.example.t1.slot8;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "sanpham")
public class Slot8SanPham {
    @Id
    private Integer id;
    private Integer giasanpham;
    private String hinhanhsanpham;
    private Integer idsanpham;
    private String motasanpham;
    private String tensanpham;

    public Slot8SanPham(Integer id, Integer giasanpham, String hinhanhsanpham, Integer idsanpham, String motasanpham, String tensanpham) {
        this.id = id;
        this.giasanpham = giasanpham;
        this.hinhanhsanpham = hinhanhsanpham;
        this.idsanpham = idsanpham;
        this.motasanpham = motasanpham;
        this.tensanpham = tensanpham;
    }

    public Slot8SanPham() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getGiasanpham() {
        return giasanpham;
    }

    public void setGiasanpham(Integer giasanpham) {
        this.giasanpham = giasanpham;
    }

    public String getHinhanhsanpham() {
        return hinhanhsanpham;
    }

    public void setHinhanhsanpham(String hinhanhsanpham) {
        this.hinhanhsanpham = hinhanhsanpham;
    }

    public Integer getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(Integer idsanpham) {
        this.idsanpham = idsanpham;
    }

    public String getMotasanpham() {
        return motasanpham;
    }

    public void setMotasanpham(String motasanpham) {
        this.motasanpham = motasanpham;
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }
}
