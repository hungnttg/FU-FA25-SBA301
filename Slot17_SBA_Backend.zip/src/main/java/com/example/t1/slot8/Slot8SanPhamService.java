package com.example.t1.slot8;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class Slot8SanPhamService {
    private final Slot8SanPhamRepository repo;
    public Slot8SanPhamService(Slot8SanPhamRepository repo) {
        this.repo = repo;
    }
    public List<Slot8SanPham> findAll() {
        return repo.findAll();
    }
    public Optional<Slot8SanPham> findById(Integer id) {
        return repo.findById(id);
    }
    public Slot8SanPham save(Slot8SanPham slot8SanPham) {
        return repo.save(slot8SanPham);
    }
    public void deleteById(Integer id) {
        repo.deleteById(id);
    }
}
