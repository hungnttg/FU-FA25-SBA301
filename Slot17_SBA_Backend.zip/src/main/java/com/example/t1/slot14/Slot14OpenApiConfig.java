package com.example.t1.slot14;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Slot14OpenApiConfig {
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Slot14 REST API")
                        .version("1.0")
                        .description("Demo API Slot14 với Versioning, HATEOAS và Swagger"));
    }
}
