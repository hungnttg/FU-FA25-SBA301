package com.example.t1.slot14;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/slot14/users")
@CrossOrigin(
        origins = "http://localhost:3000",
        allowedHeaders = "*",
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.OPTIONS}
)
@Tag(name = "Users API", description = "Quản lý Users Slot14 với versioning")
public class Slot14UserController {

    @GetMapping(headers = "X-API-VERSION=1")
    @Operation(summary = "Lấy danh sách user version 1")
    public List<Slot14User> getUsersV1() {
        return Arrays.asList(
                new Slot14User(1L, "John", "john@example.com"),
                new Slot14User(2L, "Jane", "jane@example.com")
        );
    }

    @GetMapping(headers = "X-API-VERSION=2")
    @Operation(summary = "Lấy danh sách user version 2")
    public List<Slot14User> getUsersV2() {
        return Arrays.asList(
                new Slot14User(1L, "John", "JOHN@EXAMPLE.COM"),
                new Slot14User(2L, "Jane", "JANE@EXAMPLE.COM")
        );
    }
}
/*
Truy cập Swagger UI
URL: http://localhost:8083/swagger-ui/index.html
Bạn sẽ thấy 2 endpoint version 1 và 2 với header "X-API-VERSION"
Có thể test trực tiếp từ Swagger UI.
* */