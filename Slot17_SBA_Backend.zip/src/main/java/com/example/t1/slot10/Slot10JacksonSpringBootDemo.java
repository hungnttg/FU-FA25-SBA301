package com.example.t1.slot10;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@SpringBootApplication
@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class Slot10JacksonSpringBootDemo {

    public static void main(String[] args) {
        SpringApplication.run(Slot10JacksonSpringBootDemo.class, args);
    }

    // =================== Model ===================
    static class User {
        private String name;

        @JsonSerialize(using = LocalDateSerializer.class)
        @JsonDeserialize(using = LocalDateDeserializer.class)
        private LocalDate birthday;

        public User() {}

        public User(String name, LocalDate birthday) {
            this.name = name;
            this.birthday = birthday;
        }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public LocalDate getBirthday() { return birthday; }
        public void setBirthday(LocalDate birthday) { this.birthday = birthday; }
    }

    // =================== Custom Serializer ===================
    static class LocalDateSerializer extends JsonSerializer<LocalDate> {
        private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        @Override
        public void serialize(LocalDate value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
            gen.writeString(value == null ? null : value.format(formatter));
        }
    }

    // =================== Custom Deserializer ===================
    static class LocalDateDeserializer extends JsonDeserializer<LocalDate> {
        private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        @Override
        public LocalDate deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            String date = p.getText();
            return (date == null || date.isEmpty()) ? null : LocalDate.parse(date, formatter);
        }
    }

    // =================== Controller ===================
    @GetMapping("/user")
    public User getUser() {
        return new User("Nguyen Quang Hung", LocalDate.of(1990, 5, 20));
    }

    @PostMapping(value = "/user", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String createUser(@RequestBody User user) {
        return "Received user: " + user.getName() + ", birthday: " + user.getBirthday();
    }
}
