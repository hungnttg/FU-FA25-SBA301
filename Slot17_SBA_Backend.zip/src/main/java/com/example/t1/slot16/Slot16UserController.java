package com.example.t1.slot16;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/slot16") // Tiền tố Slot16 cho tất cả endpoint
@CrossOrigin(origins = "http://localhost:3000") // fix CORS
public class Slot16UserController {

    private static Map<Long, Slot16User> users = new HashMap<>();

    static {
        users.put(1L, new Slot16User(1L, "John", "john@example.com"));
        users.put(2L, new Slot16User(2L, "Jane", "jane@example.com"));
    }

    // Danh sách users với HATEOAS _links
    @GetMapping("/users")
    public List<Map<String,Object>> getUsers() {
        List<Map<String,Object>> result = new ArrayList<>();
        for (Slot16User u : users.values()) {
            Map<String,Object> m = new HashMap<>();
            m.put("id", u.getId());
            m.put("name", u.getName());
            m.put("email", u.getEmail());

            Map<String,String> links = new HashMap<>();
            // URL đầy đủ có tiền tố Slot16
            links.put("self", "http://localhost:8083/slot16/users/" + u.getId());
            m.put("_links", links);

            result.add(m);
        }
        return result;
    }

    // Chi tiết user
    @GetMapping("/users/{id}")
    public Slot16User getUser(@PathVariable Long id) {
        return users.get(id);
    }
}

//Khi gọi GET /slot16/users
//http://localhost:8083/slot16/users
//Client có thể dùng _links.self.href
// để điều hướng tới chi tiết user mà không cần biết URL cứng.
