package com.example.t1.slot3;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/sanpham")
//cho phep React goi API
@CrossOrigin(origins = "http://localhost:3000")
public class SanPhamController {
    private final SanPhamRepository repo;
    public SanPhamController(SanPhamRepository repo) {
        this.repo = repo;
    }
    @GetMapping("/get")
    public List<SanPham> getAll() {
        return repo.findAll();
    }
}
