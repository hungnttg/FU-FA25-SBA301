package com.example.t1.slot8;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:3000")
public class Slot8SanPhamController {
    private final Slot8SanPhamService service;
    public Slot8SanPhamController(Slot8SanPhamService service) {
        this.service = service;
    }
    @GetMapping
    public List<Slot8SanPham> getAll() {
        return service.findAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Slot8SanPham> getById(@PathVariable Integer id) {
        return service.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public ResponseEntity<Slot8SanPham> create(@RequestBody Slot8SanPham sp) {
        Slot8SanPham saved = service.save(sp);
        return ResponseEntity.ok(saved);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Slot8SanPham> update(@PathVariable Integer id, @RequestBody Slot8SanPham sp) {
        return service.findById(id)
                .map(existing -> {
                    existing.setTensanpham(sp.getTensanpham());
                    existing.setGiasanpham(sp.getGiasanpham());
                    existing.setHinhanhsanpham(sp.getHinhanhsanpham());
                    existing.setMotasanpham(sp.getMotasanpham());
                    existing.setIdsanpham(sp.getIdsanpham());

                    Slot8SanPham updated = service.save(existing);
                    return ResponseEntity.ok(updated);
                }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
