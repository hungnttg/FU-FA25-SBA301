package com.example.t1.slot8;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Slot8SanPhamRepository extends JpaRepository<Slot8SanPham, Integer> {
    //truy van tuy y neu can
}
