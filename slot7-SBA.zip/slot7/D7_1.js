//goi API 1 lan khi mount (fetch)
import { useEffect,useState } from "react";
function D7_1(){
    //code
    const [posts,setPosts]=useState([]);
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts?_limit=5")
        .then((res)=>res.json())
        .then((data)=>setPosts(data));
    },[]); //chay 1 lan khi mount
    //layout
    return(
        <div style={{padding:"20px"}}>
            <h1>Danh sach bai viet</h1>
            <ul>
                {posts.map((p)=>(
                    <li key={p.id}>{p.title}</li>
                ))}
            </ul>
        </div>
    );
}
export default D7_1;