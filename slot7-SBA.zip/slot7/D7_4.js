//xu ly loi khi doc du lieu tu API
import { useEffect,useState } from "react";
export default function D7_4(){
    //code
    const [users,setUsers]=useState([]);
    const [loading, setLoading]=useState(true);
    const [error,setError]=useState(null);
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((res)=>{
            if(!res.ok) throw new Error("Loi khi fetch du lieu");
            return res.json();
        })
        .then((data)=> setUsers(data))
        .catch((err)=>setError(err.message))
        .finally(()=>setLoading(false));
    },[]);
    if(loading) return <h2>Dang tai du lieu....</h2>
    if(error) return <h2 style={{color:"red"}}>Loi: {error}</h2>
    //layout
    return(
        <div style={{padding:"20px"}}>
            <h2>Danh sach nguoi dung</h2>
            <ul>
                {users.map((u)=>(
                    <li key={u.id}>{u.name} - {u.email}</li>
                ))}
            </ul>
        </div>
    );
}