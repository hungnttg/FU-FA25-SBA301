//cleanup trong useEffect
import { useEffect,useState } from "react";
export default function D7_3(){
    //code
    const [width,setWidth]=useState(window.innerWidth);
    useEffect(()=>{
        const handleResize = () => setWidth(window.innerWidth);//dinh nghia ham
        window.addEventListener("resize",handleResize);//xu ly su kien
        //cleanup khi component unmount
        return () =>{
            window.removeEventListener("resize",handleResize);
        };
    },[]);
    //layout
    return(
        <div style={{padding:"20px"}}>
            <h2>Chieu rong man hinh {width}px</h2>
        </div>
    );
}