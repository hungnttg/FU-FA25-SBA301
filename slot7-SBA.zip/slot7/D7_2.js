//su dung useEffect co dependency (search possts by userId)
import { useEffect,useState } from "react";
export default function D7_2(){
    //code
    const [userId,setUserId]=useState(1);
    const [posts,setPosts]=useState([]);
    useEffect(()=>{
        fetch(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`)
        .then((res)=>res.json())
        .then((data) => setPosts(data));
    },[userId]);
    //layout
    return(
        <div style={{padding:"20px"}}>
            <h1>Bai viet cua user {userId}</h1>
            <button onClick={()=>setUserId(1)}>User 1</button>
            <button onClick={()=>setUserId(2)}>User 2</button>
            <button onClick={()=>setUserId(3)}>User 3</button>
            <ul>
                {posts.map((p)=>(
                    <li key={p.id}>{p.title}</li>
                ))}
            </ul>
        </div>
    );
}