//npm i axios bootstrap
import React,{useEffect,useState} from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
export default function Slot21(){
    const [products,setProducts]=useState([]);
    const [form,setForm]=useState({id:"",name:"",price:"",description:""});
    const api = "http://localhost:8083/slot221/products";
    //load du lieu
    useEffect(()=>{
        const fetchProducts = async () =>{
            try {
                const res=await axios.get(api);//doc du lieu tu server
                setProducts(res.data);//cap nhat vao state

            } catch (error) {
                console.error("Loi tai san pham: ",error);
            }
        };
        //goi ham
        fetchProducts();
    },[]);//chi chay 1 lan khi load trang
    //Ham them, cap nhat san pham
    const submit = async e => {
        e.preventDefault();//cam reload trang
        try {
            if(form.id){//neu da co id
                await axios.put(`${api}/${form.id}`,form);//cap nhat
            }
            else {
                await axios.post(api,form);//tao moi
            }
            const res = await axios.get(api); //tra ve ket qua
            setProducts(res.data);//cap nhat ket qua vao trang thai
        } catch (error) {
            console.error("Loi khi luu: ",error);
        }
    };
    //sua, xoa
    const edit = p => setForm(p); //ham edit
    const del = async id => {
        if(window.confirm("Ban co chac muon xoa san pham nay khong")){
            try {
                await axios.delete(`${api}/${id}`);//thuc hien xoa
                const res = await axios.get(api);//tra ve ket qua cho frontend
                setProducts(res.data);//cap nhat vao trang thai
            } catch (error) {
                console.error("Loi khi xoa: ",error);
            }
        }
    };
    //giao dien
    return(
        <div className="container mt-4">
            <h1 className="mb-3">Quan tri san pham</h1>
            <form onSubmit={submit} className="mb-4">
                <input
                    className="form-control mb-2" placeholder="Ten san pham"
                    value={form.name}
                    onChange={e=>setForm({...form,name: e.target.value})}
                    required
                />
                <input
                    className="form-control mb-2" placeholder="Gia san pham"
                    value={form.price}
                    onChange={e=>setForm({...form,price: e.target.value})}
                    required
                />
                <input
                    className="form-control mb-2" placeholder="Mo ta san pham"
                    value={form.description}
                    onChange={e=>setForm({...form,description: e.target.value})}
                    required
                />
                <button className="btn btn-primary">
                    {form.id ? "Cap nhat" : "Them moi"}
                </button>
            </form>
            {/* hien thi */}
            <table className="table table-bordered">
                <thead className="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Ten</th>
                        <th>Gia</th>
                        <th>Mo ta</th>
                        <th width="150">Hanh dong</th>
                    </tr>
                </thead>
                <tbody>
                    {products.map(p=>(
                        <tr key={p.id}>
                            <td>{p.id}</td>
                            <td>{p.name}</td>
                            <td>{p.price}</td>
                            <td>{p.description}</td>
                            <td>
                                <button onClick={()=>edit(p)} className="btn btn-warning">
                                    Sua
                                </button>
                                <button onClick={()=>del(p.id)} className="btn btn-danger">
                                    Xoa
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}