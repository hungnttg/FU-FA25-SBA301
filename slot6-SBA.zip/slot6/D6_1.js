import React,{useState,useEffect} from "react";
import {Navbar,Nav,Container,Card,Button,Row,Col,Modal,Form,Spinner} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
function D6_1(){
    //http://localhost:8083/PE2025/api/sanpham/get
    //id
    //tensanpham
    //giasanpham
    //hinhanhsanpham
    //motasanpham
    //idsanpham
    const [products,setProducts]=useState([]);//quan ly san pham
    const [showModal,setShowModal]=useState(false);//chua hien thi modal
    const [selectedProduct, setSelectedProduct]=useState(null);//quan ly trang thai chon
    const [showLogin,setShowLogin]=useState(false);//quan ly trang thai login
    const [loading,setLoading]=useState(true);//quan ly trang thai load du lieu
    //=== thu hien load du lieu
    useEffect(()=>{
        fetch("http://localhost:8083/PE2025/api/sanpham/get")//link doc du lieu
        .then((res)=>res.json()) //chuyen sang json
        .then((data)=>{
            setProducts(data); //cap nhat du lieu doc duco vao products
            setLoading(false);//thay doi trang thai ngung load
        })
        .catch((err)=>{
            console.error("Loi khi tai du lieu: ",err);
            setLoading(false);
        });
    },[]);
    //ham xu ly hien thi chi tiet
    const handleShowDetail = (product) =>{
        setSelectedProduct(product);//chon san pham
        setShowModal(true);//hien thi modal
    };
    //xu ly login
    const handleLoginSubmit = (e) =>{
        e.preventDefault();//cam gui tham so mac dinh khi reload trang
        alert("Dang nhap thanh cong");
        setShowLogin(false);
    };
    //giao dien
    return(
        <>
            {/* Navbar */}
            <Navbar bg="light" expand="lg" fixed="top" className="shadow-sm">
                <Container>
                    <Navbar.Brand href="#">Shop</Navbar.Brand>
                    <Navbar.Toggle />
                    <Navbar.Collapse>
                        <Nav className="me-auto">
                            <Nav.Link href="#">Trang chu</Nav.Link>
                            <Nav.Link href="#">San pham</Nav.Link>
                            <Nav.Link href="#">Gio hang</Nav.Link>
                        </Nav>
                        <Button variant="outline-primary" onClick={()=> setShowLogin(true)}>
                            Dang nhap
                        </Button>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
            {/* Nou dung */}
            <div style={{marginTop: "90px"}}>
                <Container>
                    {loading ? (
                        <div className="text-center my-5">
                            <Spinner animation="border" />
                            <p>Dang tai san pham...</p>
                        </div>
                    ) : (
                        // dod du lieu tu API
                        <Row>
                            {products.map((product)=>(
                                <Col key={product.id} md={3} className="mb-4">
                                    <Card className="h-100 shadow-sm">
                                        <Card.Img
                                            variant="top"
                                            src={product.hinhanhsanpham}
                                            style={{height:"200px", objectFit:"contain"}}
                                        />
                                        <Card.Body>
                                            <Card.Title
                                                className="text-truncate"
                                                title={product.tensanpham}
                                            >
                                                {product.tensanpham}
                                            </Card.Title>
                                            <Card.Text className="text-danger fw-bold">
                                                {product.giasanpham.toLocaleString()} d
                                            </Card.Text>
                                            <Button
                                                variant="primary"
                                                onClick={()=>handleShowDetail(product)}
                                            >Xem chi tiet</Button>
                                        </Card.Body>
                                    </Card>
                                </Col>
                            ))}
                        </Row>
                        
                    )}
                </Container>
            </div>
            {/* dinh nghia Modal chi tiet san pham */}
            <Modal show={showModal} onHide={()=> setShowModal(false)} centered>
                <Modal.Header closeButton>
                    <Modal.Title>{selectedProduct?.tensanpham}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <img
                        src={selectedProduct?.hinhanhsanpham}
                        className="img-fluid mb-3"
                    />
                    <p className="text-danger fw-bold">
                        Gia: {selectedProduct?.giasanpham.toLocaleString()} d
                    </p>
                    <p>{selectedProduct?.motasanpham}</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={()=>setShowModal(false)}>
                        Dong
                    </Button>
                    <Button variant="success">Them vao gio</Button>
                </Modal.Footer>
            </Modal>
        </>
    );

}
export default D6_1;